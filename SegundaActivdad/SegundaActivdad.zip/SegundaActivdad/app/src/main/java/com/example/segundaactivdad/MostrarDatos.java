package com.example.segundaactivdad;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MostrarDatos extends AppCompatActivity {
TextView Nombre2,Telefono2,Correo2,Descripcion2;
Button Editar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_datos);
        Nombre2=(TextView)findViewById(R.id.Nombre2);
        Telefono2=(TextView)findViewById(R.id.Telefono2);
        Correo2=(TextView)findViewById(R.id.Correo2);
        Descripcion2=(TextView)findViewById(R.id.Descripcion2);
        Editar=(Button)findViewById(R.id.Editar);
        Editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent( MostrarDatos.this, MainActivity.class);
                startActivity(intent);
            }
        });
        mostrarDato();
    }

    private void mostrarDato() {
        Bundle datos=this.getIntent().getExtras();
        String nombre=datos.getString("name");
        String telefono=datos.getString("tele");
        String correo=datos.getString("corre");
        String descripcion=datos.getString("desc");
        Nombre2.setText(nombre);
        Telefono2.setText(telefono);
        Correo2.setText(correo);
        Descripcion2.setText(descripcion);
}
}